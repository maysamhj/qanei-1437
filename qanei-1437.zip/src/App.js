import React from 'react';
import FooterSection from './Footer';
import HeaderSection from './Header';
import LandingShabak from './landingComponents/landingShabak';

function App() {
  return (
    <div className="app">
      <div className="container">
        <HeaderSection />
        <div className="content-section">
          <LandingShabak />
        </div>
      </div>
      <FooterSection />
    </div>
  );
}

export default App;
